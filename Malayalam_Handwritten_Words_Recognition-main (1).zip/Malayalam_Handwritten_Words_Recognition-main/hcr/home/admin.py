from django.contrib import admin
from .models import UpImages

# Register your models here.

admin.site.register(UpImages)